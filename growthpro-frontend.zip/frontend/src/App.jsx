import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !location) return alert("Please fill out all fields");
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/business-data', { name, location });
      setData({ ...response.data, name, location });
    } catch (err) {
      alert('Error fetching data');
    }
    setLoading(false);
  };

  const regenerateHeadline = async () => {
    if (!name || !location) return;
    try {
      const response = await axios.get(`http://localhost:5000/regenerate-headline?name=${name}&location=${location}`);
      setData(prev => ({ ...prev, headline: response.data.headline }));
    } catch (err) {
      alert('Failed to regenerate headline');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <h1 className="text-2xl font-bold mb-6">GrowthProAI Dashboard</h1>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md w-full max-w-md space-y-4">
        <input
          type="text"
          placeholder="Business Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full border p-2 rounded"
        />
        <input
          type="text"
          placeholder="Location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="w-full border p-2 rounded"
        />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
          Submit
        </button>
      </form>

      {loading && <p className="mt-4 text-gray-700">Loading...</p>}

      {data && (
        <div className="mt-6 p-4 bg-white rounded-lg shadow-md w-full max-w-md">
          <p className="text-lg font-semibold">Rating: {data.rating}★</p>
          <p>Reviews: {data.reviews}</p>
          <p className="mt-2 italic">"{data.headline}"</p>
          <button
            onClick={regenerateHeadline}
            className="mt-4 bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
          >
            Regenerate SEO Headline
          </button>
        </div>
      )}
    </div>
  );
}

export default App;
