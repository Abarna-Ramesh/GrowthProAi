const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

const headlines = [
  "Why {name} is {location}'s Sweetest Spot in 2025",
  "{name} is Revolutionizing Local Flavor in {location}",
  "Discover {name}: {location}'s Hidden Gem",
  "What Makes {name} a Must-Visit in {location}?",
  "Top Reasons {name} is Trending in {location}"
];

function generateHeadline(name, location) {
  const template = headlines[Math.floor(Math.random() * headlines.length)];
  return template.replace("{name}", name).replace("{location}", location);
}

app.post('/business-data', (req, res) => {
  const { name, location } = req.body;
  const rating = (Math.random() * (5 - 3.5) + 3.5).toFixed(1);
  const reviews = Math.floor(Math.random() * 300);
  const headline = generateHeadline(name, location);
  res.json({ rating: parseFloat(rating), reviews, headline });
});

app.get('/regenerate-headline', (req, res) => {
  const { name, location } = req.query;
  const headline = generateHeadline(name, location);
  res.json({ headline });
});

app.listen(port, () => {
  console.log(`Backend server is running on http://localhost:${port}`);
});
